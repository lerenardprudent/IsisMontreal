var map;
var request;
var infowindow;
var loca;
var bnds;
var evlis;		//event listener
var drawman;			//drawing manager
var mymarkers = [];		//my markers
var semarkers = [];		//search results markers
var markcount = 0;
var selectedShape; //shapes vars
var myShapes = new Array();
var shapeID = 0;
var geocoder = new google.maps.Geocoder();

$(function() 
{
	$( "#maindiv" ).draggable({ handle:"div.dragpanel" });			// cancel:"div.mapdivclass"
	$( "div.dragpanel" ).disableSelection();
	//$( "#maindiv" ).resizable({alsoResize:"#mapdiv", maxHeight:600, maxWidth:900, minHeight:400, minWidth:500 }, { stop: function( e, ui ) {alert(ui.size.height)}});
	$( "#maindiv" ).resizable({maxHeight:600, maxWidth:1000, minHeight:460, minWidth:600 }, 
	{
		start: function( e, ui )
		{
			google.maps.event.trigger(map, 'resize');
			loca = new google.maps.LatLng(map.getCenter().lat(), map.getCenter().lng());
			bnds = map.getBounds();

		}
	}, 
	{ 
		resize: function( e, ui ) 
		{ 
			//document.getElementById('findkwds').value = ui.size.width + " " + ui.size.height;
			//resz = true;
			document.getElementById('infopanel').style.width = (ui.size.width - 6) + "px"; 
			document.getElementById('mapdiv').style.width = ui.size.width + "px"; 
			document.getElementById('mapdiv').style.height = (ui.size.height - 100) + "px"; 
			document.getElementById('results').style.left = (ui.size.width - 200) + "px"; 
		}
	}, 
	{
		stop: function( e, ui )
		{
			google.maps.event.trigger(map, 'resize');
			map.setCenter(loca);
			map.fitBounds(bnds);
		}
	});
	//$("#maindiv").mouseup( function(event){ if(resz){google.maps.event.trigger(map, 'resize';)} resz = false; }); 
});

function geocodePosition(pos) 
{
	geocoder.geocode({ latLng: pos }, function(responses) { if (responses && responses.length > 0) { updateMarkerAddress(responses[0].formatted_address); } else { updateMarkerAddress('Address not available here.'); }});
}

function updateMarkerStatus(str) 
{
	document.getElementById('markerStatus').innerHTML = str;
}

function updateMarkerPosition(latLng) 
{
	document.getElementById('infolatlng').value = [ latLng.lat().toFixed(3), latLng.lng().toFixed(3) ].join(', ');
}

function updateMarkerAddress(str) 
{
	document.getElementById('address').value = str;
}

function codeAddress() 
{
	var address = document.getElementById('address').value;
	geocoder.geocode
	( 
		{ 'address': address }, 
		function(results, status)
		{ 
			if (status == google.maps.GeocoderStatus.OK)
			{
				//alert(status, results[0].geometry.location)
				map.setCenter(results[0].geometry.location);
				markcount++;
				marker = new google.maps.Marker({ map:map, position:results[0].geometry.location, title:'Point ' + markcount, draggable:true, raiseOnDrag:false });
				var iconfile = 'http://maps.google.com/mapfiles/ms/icons/green-dot.png'; 
				marker.setIcon(iconfile);
				mymarkers.push(marker);
				infowindow = new google.maps.InfoWindow();
				infowindow.setOptions({maxWidth:400});
				//var cnt = "<div style='border-width:1px; border-color:#ff0000; border-style:solid; height:100px; width:100%'>" + this.title  + "<br>" + this.getPosition().lat() + " " + this.getPosition().lng() + "<br>   Test.<div>"
				google.maps.event.addListener(marker, 'click', function() { infowindow.setContent("<div style='margin:2px; padding:2px; border-width:1px; border-color:#ff0000; border-style:solid; height:100px; width:200px'>" + this.title  + "<br>" + this.getPosition().lat() + " " + this.getPosition().lng() + "<div>"); infowindow.open(map, this); });
			} 
			else 
			{
				alert('Geocode was not successful: ' + status);
			}
		}
	);
}

function initialize()
{
	loca = new google.maps.LatLng(-36.853, 174.767);
	map = new google.maps.Map(document.getElementById('mapdiv'), { zoom:10, center:loca, mapTypeId:google.maps.MapTypeId.ROADMAP });
	google.maps.event.addListener(map, 'resize', function() {  });			//updateMarkerStatus('Drag ended')
	
	//use the following code for every marker created using the drawing manager: toggledrawtools()
	/*
	var marker = new google.maps.Marker({ position:loca, title:'Point A', map:map, draggable:true, animation:null });
	mymarkers.push(marker);
	updateMarkerPosition(loca);					//update current position infolatlng.
	geocodePosition(loca);
	google.maps.event.addListener(marker, 'click', function() { geocodePosition(marker.getPosition()); });
	google.maps.event.addListener(marker, 'drag', function() { updateMarkerPosition(marker.getPosition()); });
	google.maps.event.addListener(marker, 'dragend', function() { geocodePosition(marker.getPosition()); });			//updateMarkerStatus('Drag ended')
	*/
}

function clearSelection() 
{
    if (selectedShape) {
		if(selectedShape.type!=google.maps.drawing.OverlayType.MARKER){
          selectedShape.setEditable(false);
		}
          selectedShape = null;
    }
}

function setSelection(shape) {
        clearSelection();
        selectedShape = shape;
		if(shape.type!=google.maps.drawing.OverlayType.MARKER){
       	 shape.setEditable(true);
		}
        //selectColor(shape.get('fillColor') || shape.get('strokeColor'));
	}

function deleteSelectedShape() {
        if (selectedShape) {
          selectedShape.setMap(null);
		  for(var i=0;i<myShapes;i++){
			  if(myShapes[i].id == selectedShape.id){
				  myShapes.splice(i,1);
			}
		  }
        }
}

function addInfoWindow()
{
	if (selectedShape) {
		var newWindow = new google.maps.InfoWindow({
    		content: "New window"
		});
		newWindow.open(map,selectedShape);
	}
}

function toggledrawtools()
{
	var i;
	var a = ["btn1", "btn2", "btn3", "btn4", "btn5"];
	if(document.getElementById('btn6').value == "U")
	{	
		drawman = new google.maps.drawing.DrawingManager({
		drawingMode: google.maps.drawing.OverlayType.NULL,
		drawingControl: true,
		drawingControlOptions: {
		position: google.maps.ControlPosition.TOP_CENTER,
		drawingModes: [
		  google.maps.drawing.OverlayType.MARKER,
		  google.maps.drawing.OverlayType.CIRCLE,
		  google.maps.drawing.OverlayType.POLYGON,
		  google.maps.drawing.OverlayType.POLYLINE,
		  google.maps.drawing.OverlayType.RECTANGLE
		]
		},
		markerOptions: {
		clickable: true,
		draggable: true,
		raiseOnDrag:false,
		//editable: true
		},
		circleOptions: {
		fillColor: '#ff0000',
		fillOpacity: .8,
		strokeWeight: 1,
		clickable: true,
		editable: true
		},
		polygonOptions: {
		fillColor: '#ff0000',
		fillOpacity: .8,
		strokeWeight: 1,
		clickable: true,
		editable: true
		},
		rectangleOptions: {
		fillColor: '#ff0000',
		fillOpacity: .8,
		strokeWeight: 1,
		clickable: true,
		editable: true
		},
		polylineOptions: {
		strokeWeight: 2,
		clickable: true,
		editable: true
		}
		});
		drawman.setMap(map);
		
		 google.maps.event.addListener(drawman, 'overlaycomplete', function(e) {
			
			var newShape = e.overlay;
			newShape.type = e.type;
			newShape.id = shapeID;
			shapeID++;
			
			google.maps.event.addListener(newShape, 'click', function() {
              		setSelection(newShape);
            });
			
			/*
            if (e.type != google.maps.drawing.OverlayType.MARKER) {
				myShapes.push(newShape);			
            } else {
			   mymarkers.push(newShape);
		    }
			*/
			myShapes.push(newShape);
			setSelection(newShape);
        });
		
		var editOptions = {
      		editable: true,
     		clickable: true
    	};
		
		for(i=0; i<myShapes.length; i++)
		{
			myShapes[i].setOptions(editOptions);
			
			//stop if from selecting every shape when you re-enter edit mode
			setSelection(myShapes[i]);
			clearSelection();
		}

		google.maps.event.addListener(drawman, 'drawingmode_changed', clearSelection);
		google.maps.event.addListener(map, 'click', clearSelection);
		
		document.getElementById('btn6').value = "D";
		document.getElementById('btn6').style.color = "#dd0000";
		document.getElementById('btn6').style.borderColor = "#dd0000";
		document.getElementById('edittools').style.display = "inline-block";
		for(i=0; i<a.length; i++)
		{
			document.getElementById(a[i]).disabled = true;
		}
	}
	else
	{
		drawman.setDrawingMode(null);
		drawman.setMap(null);
		
		 var editOptions = {
      		editable: false,
     		clickable: false
    	};
		
		for(var i=0;i<myShapes.length;i++)
		{
			myShapes[i].setOptions(editOptions);
		}
		
		document.getElementById('btn6').value = "U";
		document.getElementById('btn6').style.color = "#404040";
		document.getElementById('btn6').style.borderColor = "#a0a0a0";
		document.getElementById('edittools').style.display = "none";
		for(i=0; i<a.length; i++)
		{
			document.getElementById(a[i]).disabled = false;
		}
	}
}

function findplace()
{
	clearresultsarray(semarkers);
	document.getElementById('places').innerHTML = "";
	document.getElementById('results').style.visibility = "hidden";
	//var loca = new google.maps.LatLng(-37.054, 174.829);
	var gclat = map.getCenter().lat();
	var gclng = map.getCenter().lng();
	var lc = new google.maps.LatLng(gclat, gclng);
	
	var typ = document.getElementById('findtype').value;
	var rads =  parseInt(document.getElementById('findrads').value);
	var kwd = document.getElementById('findkwds').value;		//.split(" ");	for(var i=0; i<kwd.length; i++){ kwd[i] = kwd[i].trim(); alert(i + " " + kwd[i])}			//keyword array
	//var nam = "";			//name
	if(typ != "")
	{
		if(kwd != "")
		{
			request = { location:lc, radius:rads, types:[typ], keyword:[kwd] };
		}
		else
		{
			request = { location:lc, radius:rads, types:[typ] };
		}
	}
	else
	{
		if(kwd != "")
		{
			request = { location:lc, radius:rads, keyword:[kwd] };
		}
	}
	infowindow = new google.maps.InfoWindow();
	var service = new google.maps.places.PlacesService(map);
	service.nearbySearch(request, callback);
}

function callback(results, status, pagination) 
{
	if (status != google.maps.places.PlacesServiceStatus.OK){return;}
	document.getElementById('results').style.visibility = "visible";
	createMarkers(results);
	var morebtn = document.getElementById('more');
	if (pagination.hasNextPage) 
	{
		morebtn.disabled = false;
		google.maps.event.addDomListenerOnce(morebtn, 'click', function() { pagination.nextPage(); });
	}
	else
	{
		morebtn.disabled = true;
	}
}

function createMarkers(places) 			//search results
{
	bnds = new google.maps.LatLngBounds();
	var placesList = document.getElementById('places');
	for (var i = 0, place; place = places[i]; i++) 
	{
		var image = {url:place.icon, size:new google.maps.Size(40, 40), origin:new google.maps.Point(0, 0), anchor:new google.maps.Point(10,20), scaledSize:new google.maps.Size(20, 20)};
		var marker = new google.maps.Marker({ map:map, icon:image, title:place.name, position:place.geometry.location, raiseOnDrag:false });
		semarkers.push(marker);
		marker.ID = semarkers.length-1;
		infowindow = new google.maps.InfoWindow();			//infowindow does not work
		google.maps.event.addListener(marker, 'click', function() { infowindow.setContent("<div style='height:130px; width:200px'><b>" + place.name  + "</b><br>Category: <b>" + document.getElementById('findtype').value  + "</b><br>Filter: <b>" + document.getElementById('findkwds').value  + "</b><br>Position: " + this.getPosition().lat().toFixed(3) + " " + this.getPosition().lng().toFixed(3) + "<br><br><b><a href='http://treksoft.com' target='_blank'>Save</a></b>&nbsp;&nbsp;&nbsp;<b><a href='#' onClick='clearsearchmarker(" + this.ID + ")'>Remove</a></b><div>"); infowindow.open(map, this); });
		placesList.innerHTML += '<li>' + place.name + '</li>';
		bnds.extend(place.geometry.location);
	}
	map.fitBounds(bnds);
}



/*
function createMarker(place) 			//user created
{
	var marker = new google.maps.Marker({ map:map, position:place.geometry.location});
	var iconfile = 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png'; 
	marker.setIcon(iconfile);
	semarkers.push(marker);
	marker.ID = semarkers.length-1;
	//bounds.extend(place.geometry.location);
	google.maps.event.addListener(marker, 'click', function() { infowindow.setContent("<div style='height:130px; width:200px'><b>" + place.name  + "</b><br>Category: <b>" + document.getElementById('findtype').value  + "</b><br>Filter: <b>" + document.getElementById('findkwds').value  + "</b><br>Position: " + this.getPosition().lat().toFixed(3) + " " + this.getPosition().lng().toFixed(3) + "<br><br><b><a href='http://treksoft.com' target='_blank'>Save</a></b>&nbsp;&nbsp;&nbsp;<b><a href='#' onClick='clearsearchmarker(" + this.ID + ")'>Remove</a></b><div>"); infowindow.open(map, this); });
}
*/


function clearsearchmarker(id) 
{
	try{semarkers[id].setMap(null);}catch(er){semarkers[id] = null;}
}

function clearoverlays(arr) 
{
	document.getElementById('findtype').value = "";
	document.getElementById('findkwds').value = "";
	document.getElementById('findrads').value = "1000";
	document.getElementById('places').innerHTML = "";
	document.getElementById('results').style.visibility = "hidden";
	for (var i = 0; i < arr.length; i++ ) 
	{
		arr[i].setMap(null);
	}
	arr = [];
}


function clearresultsarray(arr) 
{
	for (var i = 0; i < arr.length; i++ ) 
	{
		arr[i].setMap(null);
	}
	arr = [];
}


/*
var crosshairShape = {coords:[0,0,0,0],type:'rect'};
var latlng = new google.maps.LatLng(54.62279178711505,-5.895538330078125);
var myOptions = {zoom:12,center:latlng,mapTypeId:google.maps.MapTypeId.SATELLITE,draggableCursor:'crosshair',mapTypeControlOptions:{style:google.maps.MapTypeControlStyle.DROPDOWN_MENU}};
var map = new google.maps.Map(document.getElementById("map_canvas"),myOptions);
var marker = new google.maps.Marker({
map: map,
icon: 'http://www.daftlogic.com/images/cross-hairs.gif',
shape: crosshairShape
});
marker.bindTo('position', map, 'center'); 
*/



function hidemap()
{
	clearoverlays(semarkers);
	document.getElementById('maindiv').style.visibility = "hidden";
}

function showmap(par)
{
	document.getElementById('maindiv').style.visibility = "visible";
	if(par == "T"){	initialize(); google.maps.event.addDomListener(window, 'load', initialize);}
}

function minmaxmap()
{
	if (document.getElementById('maindiv').style.visibility == "hidden")
	{
		document.getElementById('maindiv').style.visibility = "visible"
		document.getElementById('btn3').value = "Hide map"
	}
	else
	{
		document.getElementById('maindiv').style.visibility = "hidden"
		document.getElementById('btn3').value = "Show map";
	}
}

// Onload handler to fire off the app.
//google.maps.event.addDomListener(window, 'load', initialize);
